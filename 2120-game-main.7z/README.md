It is blackjack game in the Soviet interpritation. 21_2_EN - ehglisch game, 21_21 - englisch with russian translite.
